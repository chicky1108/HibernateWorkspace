package com.cg.project.beans;

import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int customerNo;
private String firstName,lastName,email;

@OneToMany(mappedBy="customer")
@MapKey
private Map<Integer,Car> car;
public Customer() {}
public Customer(int customerNo, String firstName, String lastName, String email, Map<Integer, Car> car) {
	super();
	this.customerNo = customerNo;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.car = car;
}
public int getCustomerNo() {
	return customerNo;
}
public void setCustomerNo(int customerNo) {
	this.customerNo = customerNo;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Map<Integer, Car> getCar() {
	return car;
}
public void setCar(Map<Integer, Car> car) {
	this.car = car;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + customerNo;
	result = prime * result + ((email == null) ? 0 : email.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (customerNo != other.customerNo)
		return false;
	if (email == null) {
		if (other.email != null)
			return false;
	} else if (!email.equals(other.email))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	return true;
}
@Override
public String toString() {
	return "Customer [customerNo=" + customerNo + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
			+ email + "]";
}



}
