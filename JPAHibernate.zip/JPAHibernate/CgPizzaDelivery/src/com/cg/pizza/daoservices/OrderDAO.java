package com.cg.pizza.daoservices;

import java.util.List;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.PizzaOrders;

public interface OrderDAO 
{
    PizzaOrders save(PizzaOrders order);
    boolean update(PizzaOrders order);
    PizzaOrders findOne(int orderId);
    List<PizzaOrders> findAll();
}
